package com.example.paqueteria_barranco

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
